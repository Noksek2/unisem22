import dht
from servo import Servo
from machine import Pin,PWM, ADC,SoftI2C
from time import sleep

from i2c_lcd import I2cLcd
from lcd_api import LcdApi

motor=Servo(pin=13)

cds=ADC(Pin(36))
cds.atten(ADC.ATTN_11DB)
cds.width(ADC.WIDTH_12BIT)

touch1=Pin(17,Pin.IN)
touch2=Pin(5,Pin.IN)
touch3=Pin(18,Pin.IN)
touch4=Pin(19,Pin.IN)

ledr=Pin(27,Pin.OUT)
ledg=Pin(26,Pin.OUT)
ledb=Pin(25,Pin.OUT)
LEDs=[ledr,ledg,ledb]

BTNs=[touch1,touch2,touch3,touch4]

pos=0

d=dht.DHT11(Pin(14))

def kilkil():
    while True:
        d.measure()
        hum=d.humidity()
        tem=d.temperature()
        print(f'습도는 {d.humidity()}')
        print(f'온도는 {d.temperature()}')
        
        shit=(1.8*tem)-(0.55*(1-hum/100.0)*(1.8*tem-26))+32
        print(f'불쾌 지수는 {shit}')
        
        ledr.off()
        ledg.off()
        ledb.off()
        
        if shit>80:ledr.on()
        elif shit>75:ledg.on()
        elif shit>70:ledb.on()
        
        
        '''for i in range(0,3):
            if BTNs[i].value():
                LEDs[i].on()
            else:
                LEDs[i].off()
        cds_value=cds.read()
        print(cds_value)
        
        pos=cds_value/4096.0*180.0
        if pos==360:pos=0
        
        motor.move(pos)
        '''
        sleep(0.5)
