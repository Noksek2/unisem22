import machine
from machine import Pin, SoftI2C
from lcd_api import LcdApi
from i2c_lcd import I2cLcd
from time import sleep

I2C_ADDR = 0x27
I2C_NUM_ROWS = 2
I2C_NUM_COLS = 16

i2c = SoftI2C(scl=Pin(22), sda=Pin(21), freq=10000)
lcd = I2cLcd(i2c, I2C_ADDR, I2C_NUM_ROWS, I2C_NUM_COLS)

lcd.clear()

# https://maxpromer.github.io/LCD-Character-Creator/
thermometer = bytearray([0x04, 0x0A, 0x0A, 0x0A, 0x0A, 0x1B, 0x1F, 0x0E])
lcd.custom_char(0, thermometer)

umbrella = bytearray([0x00, 0x04, 0x0E, 0x1F, 0x04, 0x04, 0x14, 0x0C])
lcd.custom_char(1, umbrella)

heart = bytearray([0x00, 0x0A, 0x1F, 0x1F, 0x0E, 0x04, 0x00, 0x00])
lcd.custom_char(2, heart)

hu=bytearray([0b01010,
  0b10110,
  0b10111,
  0B01010,
  0B00010,
  0B01000,
  0B01000,
  0B01111])

nyon=bytearray(
      [0B10001,
  0B10011,
  0B10001,
  0B10011,
  0B11101,
  0B00100,
  0B01010,
  0B00100])

mo=bytearray([  0B10111,
  0B10101,
  0B10100,
  0B11100,
  0B00111,
  0B00101,
  0B10101,
  0B11101])

ah=bytearray([  0B00001,
  0B00001,
  0B00001,
  0B00001,
  0B00001,
  0B01101,
  0B10101,
  0B11111])
al=bytearray([ 0B00101,
  0B00101,
  0B00101,
  0B00101,
  0B00101,
  0B00101,
  0B00101,
  0B11001])
lcd.custom_char(3, hu)
lcd.custom_char(4, nyon)
lcd.custom_char(5,mo)
lcd.custom_char(6,ah)
lcd.custom_char(7,al)

while True:
    lcd.move_to(0,0)
    lcd.putchar(chr(6))
    lcd.putchar(chr(7))
    #lcd.putstr("Characters")
    lcd.move_to(0, 1)
    # Display thermometer
    lcd.putchar(chr(0))
    # Display umbrella
    lcd.move_to(2, 1)
    lcd.putchar(chr(1))
    # Display heart
    lcd.move_to(4, 1)
    lcd.putchar(chr(2))
    lcd.move_to(5, 1)
    lcd.putchar(chr(3))
    lcd.move_to(6, 1)
    lcd.putchar(chr(4))
    lcd.move_to(7, 1)
    lcd.putchar(chr(5))
    sleep(1)
    lcd.display_off()
    lcd.backlight_off()
    sleep(1)
    lcd.display_on()
    lcd.backlight_on()