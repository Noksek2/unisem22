from machine import Pin,PWM
from time import sleep

bz=PWM(Pin(23))
bz.duty_u16(0)

bz.duty_u16(1000)
while True:
    bz.freq(262)
    sleep(1)
    
    bz.freq(277)
    sleep(1)
    
    bz.freq(294)
    sleep(1)
    
    bz.freq(311)
    sleep(1)