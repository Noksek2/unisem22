﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Sear초래그 : Form
    {
        public Sear초래그()
        {
            InitializeComponent();

            gridRes.Columns.Add("name", "이름");
            gridRes.Columns.Add("age", "나이");

        }
        public void inittable()
        {
            gridRes.Rows.Clear();
        }
        public void addTable(string cell1,string cell2)
        {
            gridRes.Rows.Add(cell1,cell2);
        }
        private void Sear초래그_Load(object sender, EventArgs e)
        {
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
