
using System.Configuration;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Text;
namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        Sear�ʷ��� win = new Sear�ʷ���();
        public Form1()
        {
            InitializeComponent();
            
            win.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 0)
            {
                comboBox1.Items.Add(textBox1.Text);
                Random rand = new Random();
                dataGridView1.Rows.Add(textBox1.Text, rand.Next(10, 50).ToString());
            }
        }

        private void button_del_Click(object sender, EventArgs e)
        {
            var res=MessageBox.Show("��¥ �������?", "����", MessageBoxButtons.YesNo);
            if (res == DialogResult.Yes)
            {
                if (dataGridView1.Rows.Count > 1)
                {
                    MessageBox.Show("�� ������");
                    comboBox1.Items.Clear();
                    dataGridView1.Rows.Clear();
                }
                else { MessageBox.Show("����͵� ���� ");}
                }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.Columns.Add("name", "�̸�");
            dataGridView1.Columns.Add("age", "����");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!win.Visible) win.Show();
            int cnt = 0;
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                if (dataGridView1.Rows[i].Cells[0].Value?.ToString() ==
                    text_search.Text)
                {
                    cnt++;

                    win.addTable(
                        dataGridView1.Rows[i].Cells[0].Value?.ToString(),
                        dataGridView1.Rows[i].Cells[1].Value?.ToString());
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "CSV files(*.csv)|*.csv";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                dataGridView1.Rows.Clear();
                StreamReader rd = new StreamReader(openFileDialog.FileName, Encoding.Default);

                while (!rd.EndOfStream)
                {
                    String line = rd.ReadLine();
                    string[] cols = line.Split(',');
                    dataGridView1.Rows.Add(cols[0], cols[1]);
                }
                label_filename.Text = openFileDialog.FileName;
                rd.Close();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void SaveMyFile(string path)
        {
            FileStream fs = new FileStream(label_filename.Text,
                FileMode.Create, FileAccess.Write);
            string buf = "";
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                buf += dataGridView1.Rows[i].Cells[0].Value?.ToString() +
                    ',' +
                dataGridView1.Rows[i].Cells[1].Value?.ToString() + '\n';

            }
            var byt = Encoding.Default.GetBytes(buf);
            fs.Write(byt, 0, byt.Length);
            fs.Close();
            MessageBox.Show($"\"{path}\"�� ����� ����");
        }
        private void button5_Click(object sender, EventArgs e)
        {
            if (label_filename.Text == "(None)") button_newsave_Click(sender, e);
            else SaveMyFile(label_filename.Text);
        }

        private void button_newsave_Click(object sender, EventArgs e)
        {
            SaveFileDialog sv=new SaveFileDialog();
            sv.Title = "�����ϱ�";
            sv.Filter= "CSV files(*.csv)|*.csv";
            if (sv.ShowDialog() == DialogResult.OK)
            {
                SaveMyFile(sv.FileName);
                label_filename.Text = sv.FileName;
            }
        }
    }
}
