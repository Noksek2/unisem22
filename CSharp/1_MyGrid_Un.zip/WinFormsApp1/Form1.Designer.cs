﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            comboBox1 = new ComboBox();
            textBox1 = new TextBox();
            button_del = new Button();
            dataGridView1 = new DataGridView();
            text_search = new TextBox();
            label1 = new Label();
            button2 = new Button();
            button3 = new Button();
            label_filename = new Label();
            button_newsave = new Button();
            button5 = new Button();
            groupBox1 = new GroupBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(267, 11);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 1;
            button1.Text = "추가";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(13, 12);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 2;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(140, 12);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(121, 23);
            textBox1.TabIndex = 3;
            // 
            // button_del
            // 
            button_del.Location = new Point(97, 668);
            button_del.Name = "button_del";
            button_del.Size = new Size(103, 31);
            button_del.TabIndex = 4;
            button_del.Text = "전체 지우기";
            button_del.UseVisualStyleBackColor = true;
            button_del.Click += button_del_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 148);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(330, 510);
            dataGridView1.TabIndex = 5;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // text_search
            // 
            text_search.Location = new Point(45, 19);
            text_search.Name = "text_search";
            text_search.Size = new Size(135, 23);
            text_search.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(8, 19);
            label1.Name = "label1";
            label1.Size = new Size(31, 15);
            label1.TabIndex = 7;
            label1.Text = "검색";
            // 
            // button2
            // 
            button2.Location = new Point(186, 19);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 8;
            button2.Text = "검색";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(267, 111);
            button3.Name = "button3";
            button3.Size = new Size(75, 31);
            button3.TabIndex = 9;
            button3.Text = "파일 열기";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label_filename
            // 
            label_filename.AutoSize = true;
            label_filename.Location = new Point(15, 119);
            label_filename.Name = "label_filename";
            label_filename.Size = new Size(44, 15);
            label_filename.TabIndex = 10;
            label_filename.Text = "(None)";
            // 
            // button_newsave
            // 
            button_newsave.Location = new Point(267, 668);
            button_newsave.Name = "button_newsave";
            button_newsave.Size = new Size(75, 31);
            button_newsave.TabIndex = 11;
            button_newsave.Text = "새로 저장";
            button_newsave.UseVisualStyleBackColor = true;
            button_newsave.Click += button_newsave_Click;
            // 
            // button5
            // 
            button5.Location = new Point(206, 668);
            button5.Name = "button5";
            button5.Size = new Size(55, 31);
            button5.TabIndex = 12;
            button5.Text = "저장";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(text_search);
            groupBox1.Controls.Add(button2);
            groupBox1.Location = new Point(12, 56);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(267, 49);
            groupBox1.TabIndex = 13;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ClientSize = new Size(354, 711);
            Controls.Add(groupBox1);
            Controls.Add(button5);
            Controls.Add(button_newsave);
            Controls.Add(label_filename);
            Controls.Add(button3);
            Controls.Add(dataGridView1);
            Controls.Add(button_del);
            Controls.Add(textBox1);
            Controls.Add(comboBox1);
            Controls.Add(button1);
            MaximizeBox = false;
            Name = "Form1";
            Text = "Omma na calhecci hhhhh";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button1;
        private ComboBox comboBox1;
        private TextBox textBox1;
        private Button button_del;
        private DataGridView dataGridView1;
        private TextBox text_search;
        private Label label1;
        private Button button2;
        private Button button3;
        private Label label_filename;
        private Button button_newsave;
        private Button button5;
        private GroupBox groupBox1;
    }
}
