﻿namespace WinFormsApp1
{
    partial class Sear초래그
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            gridRes = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)gridRes).BeginInit();
            SuspendLayout();
            // 
            // gridRes
            // 
            gridRes.AllowUserToAddRows = false;
            gridRes.AllowUserToDeleteRows = false;
            gridRes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            gridRes.Location = new Point(12, 12);
            gridRes.Name = "gridRes";
            gridRes.ReadOnly = true;
            gridRes.Size = new Size(318, 426);
            gridRes.TabIndex = 0;
            gridRes.CellContentClick += dataGridView1_CellContentClick;
            // 
            // Sear초래그
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(345, 450);
            Controls.Add(gridRes);
            Name = "Sear초래그";
            Text = "Sear초래그";
            Load += Sear초래그_Load;
            ((System.ComponentModel.ISupportInitialize)gridRes).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView gridRes;
    }
}